| Task                                                                                                                      | Estimate | Status |
| ------------------------------------------------------------------------------------------------------------------------- | :------: | :----: |
| 1 Research & fill out Q&A                                                                                                 |   1hr    |  DONE  |
| 2 Create base application stack                                                                                           |   1hr    |  DONE  |
| 3 Add a section to README with simple instructions to run the app                                                         |  10mins  |  DONE  |
| 4 Create a search page with a search bar                                                                                  |  20mins  |  DONE  |
| 5 Create a results page that displays all (open, closed, pull requests) issues from the search query.                     |    1h    |  DONE  |
| 6 Implement filtering by open, closed, or pull requests on the results page + icons.                                      |    1h    |  DONE  |
| 7 Bonus - Cover the case of an error fetching the results.                                                                |  10mins  |  DONE  |
| 8 Bonus - Allow users to be able to share states via URLs to other users so that they can view results without searching! |  10mins  |  DONE  |
| 9 Fill out "Looking back" section in README                                                                               |  10mins  |  DONE  |
| **Total**                                                                                                                 | **5hrs** |
