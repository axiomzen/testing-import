# QnA

### Planning

> What do you think are the greatest areas of risk in completing the project?

- Not understanding, or misunderstanding the full scope of work that needs to be done
- Estimating, breaking the product/feature down to smaller chunks and evaluating the level of effort, complexity and time required is very helpful, estimating wrong can create delivery problems. For ex: If this app is a prototype or mvp, should we write tests and estimate for that in this case? Will we have time later to rewrite the app properly or will we need to convert the MVP app to the real production app
- Wasting time with tech that is not essential for the MVP, for ex: Should we set up Redux? Can we use Context API as a quick and dirty global store? Do we even need a global store. Can XState help us speed things up by sorting out all the state ahead of time?

> What changes/additions would you make to the design?

- I would possibly make the issue "status" icons a littler bigger, pick a lighter color so they are easier for the user to pick up visually. Or move the icons as is to the bottom right corner in the white area of each issue box. For a MVP not much really "needs" to change.

> List a two or three features that you would consider implementing in the future that would add significant value to the project.

#### **1. Comments quick view**

**Story:**

- As a user I want to explore and scan though repos in search of suitable issues to start making OSS contributions and become an amazing OSS developer, and I want to be able to view comments in the issue via "quick view" mechanism in the UI.

**Acceptance Criteria:**

- UX & Design
  The UX & Design must serve the purpose of being able to quickly access the issue comments while browsing different issues. It must have a convienent UX flow.
- Front End
  Add a UI piece that allows the user to view the comments thread of any issue, enabling the user to "quickly" scan the information and history of the issue.

#### **2. i18n / Localization**

_Story:_

- As a user I want to explore and scan though repos in search of issues in my language

_Acceptance Criteria:_

- UX & Design
  Create necessary UI elements: language switcher an any other accompanying elements like country flags.
- Front End
  Implement the localization system with a reliable 3rd party library

#### **3. Accessibility (WCAG)**

_Story:_

- As a user I want the app to be fully accessible

_Acceptance Criteria:_

- Accessibility is covered by tests written against the axe-core package
- Forms and inputs are fully accessible
- Images have alternative (alt) text (unless they are purely for decoration)
- Images are not used for text, unless the image is part of a logo or brand name
- There is strong colour contrast between text and background
- Colour is not used as a prompt or to convey information
- Text can be increased and decreased in size by the user
- Links describe where the link is going, not the url address
- Links to documents contain the document type and file size
- All documents are available in an accessible version (ie in both Word doc and PDF)
- All parts of the website can be accessed using only the keyboard
- There is more than one way to find information (search/sitemap/navigation)
- Labels are presented next to fields that require the user to enter information
- There are no time limits imposed on users
- Pages do not contain quick flashing (ie more than three flashes a second

### Looking Back

> Describe the major design/build decisions and why you made them.

- I decided to use Create React App to save time on setting up things like React, TS, Webpack and Babel by hand. I would prefer having control over those things as CRA can make it hard to make changes to the configurations for those pieces.

- I decided to not to build a server environment (ex: serverless back end in AWS), it was not necessary since endpoints I needed did not require server side requests.

- Emotion CSS gave me access to scoped CSS, JS variables inside and an easy themeing system. Decided againts a UI framework like ReactStrap or Matrial UI since the UI pieces were minimal and could be easily built by hand, possibly faster that using a UI framework.

> How long did the assignment take (in hours)? Please break down your answer into buckets (e.g. "Learning Framework", "Coding", "Debugging").

| Task                                                                                                                      | Estimate |
| ------------------------------------------------------------------------------------------------------------------------- | :------: |
| 1 Research & fill out Q&A                                                                                                 |   1hr    |
| 2 Create base application stack                                                                                           |   1hr    |
| 3 Add a section to README with simple instructions to run the app                                                         |  10mins  |
| 4 Create a search page with a search bar                                                                                  |  20mins  |
| 5 Create a results page that displays all (open, closed, pull requests) issues from the search query.                     |    2h    |
| 6 Implement filtering by open, closed, or pull requests on the results page + icons.                                      |    1h    |
| 7 Bonus - Cover the case of an error fetching the results.                                                                |  10mins  |
| 8 Bonus - Allow users to be able to share states via URLs to other users so that they can view results without searching! |  10mins  |
| 9 Fill out "Looking back" section in README                                                                               |  10mins  |
| **Total**                                                                                                                 | **6hrs** |

> If you could go back and give yourself advice at the beginning of the project, what would it be?

- Spend a little more time planning

> Did you learn anything new?

- I tried out the react-query library for the first time, and absolutely love it.

> Do you feel that this assignment allowed you to showcase your abilities effectively?

- I beleive it did so fairly well, one of the better take home assignments I have come across.

> Are there any significant web development-related skills that you possess that were not demonstrated in this exercise? If so, what are they?

- Would have liked to show off some of my experience with custom SSR builds, Express and creating a Serverless stack. But that might have also taken too long on top.
