## **Instructions**

**Install dependencies:**

`yarn`

**Run the app locally:**

`yarn start`

**Create an app release with changelog, version increment and github release:**

`yarn release`

## **Notable Libraries**

- create react app
- emotion.sh for css
- react-router
- react-query for swr network request optimization
- flexbox grid as a drop in css grid - http://flexboxgrid.com/
- axios

![](landingPage.gif)
![](searchPage.gif)
