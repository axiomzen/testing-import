import { css } from "@emotion/core";
import theme from "./shared/theme";
import { mediaQueryMax } from "./utils/mediaQuery";

export const mainAppContainer = css`
  height: 100vh;
  padding: 5rem 1.5rem;

  h1 {
    color: #ffffff;
    font-size: 2.8rem;
    font-family: ${theme.fonts.montserratBold};

    ${mediaQueryMax(theme.breakpoints.md)} {
      font-size: 2rem;
    }
  }
`;
