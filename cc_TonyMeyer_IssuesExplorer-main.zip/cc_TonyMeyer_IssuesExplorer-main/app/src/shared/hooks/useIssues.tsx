import { useQuery } from "react-query";
import axios from "axios";

/**
 *
 *
 * @param {string} issuesUrl
 * @returns
 */
async function getIssues(issuesUrl: string) {
  const { data } = await axios.get(issuesUrl);
  return data;
}

interface Props {
  issuesUrl: string;
  reactQueryKey: string;
}

/**
 *
 *
 * @export
 * @param {Props} { issuesUrl: "https://api.github.com/repos/jonschlinkert/parse-github-url/issues", reactQueryKey: "parse-github-url" }
 * @returns
 */
export default function useIssues({ issuesUrl, reactQueryKey }: Props) {
  const issues = () => getIssues(issuesUrl);
  return useQuery(reactQueryKey, issues);
}
