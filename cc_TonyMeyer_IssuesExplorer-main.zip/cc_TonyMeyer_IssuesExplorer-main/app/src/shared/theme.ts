const theme = {
  breakpoints: {
    xs: 0,
    sm: 600,
    md: 960,
    lg: 1280,
    xl: 1920
  },
  buttons: {
    // primary: {
    //   position: "relative",
    //   display: "flex",
    //   justifyContent: "center",
    //   fontFamily: '"Oswald", sans-serif',
    //   fontSize: "100%",
    //   padding: ".5rem 2.4rem",
    //   backgroundColor: "#CBAB7A",
    //   color: "#13273E",
    //   cursor: "pointer",
    //   textAlign: "center",
    //   whiteSpace: "nowrap",
    //   transition: "all .2s ease-in",
    //   "&:hover": {
    //     backgroundColor: "#cea05a"
    //   },
    //   "&:disabled": {
    //     cursor: "default",
    //     backgroundColor: "#f4f4f4"
    //   }
    // },
  },
  colors: {
    darkBlue: "#1A237E",
    lightBlue: "#3F51B5",
    burgundy: "#880E4F",
    hotPink: "#E91E63",
    darkGrey: "#455A64",
    grey: "#607D8B",
    lightGrey: "#CFD8DC",
    white: "#FFFFFF"
  },
  fonts: {
    montserrat: "Montserrat",
    montserratLight: "Montserrat-Light",
    montserratBold: "Montserrat-Bold"
  },
  shadows: {
    small: "5px 5px 15px 5px rgba(0, 0, 0, .125)",
    medium: "5px 5px 15px 5px rgba(0,0,0,0.74)"
  }
};

export default theme;
