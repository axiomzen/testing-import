import React, { useState } from "react";
import { useHistory } from "react-router-dom";
import { searchInputContainer } from "./searchInputStyles";
import SearchIcon from "../../shared/SearchIcon";

export default function SearchInput() {
  const [value, setValue] = useState("");
  const history = useHistory();

  const handleChange = (e: any) => {
    setValue(e.target.value);
  };

  const handleSubmit = (e: any) => {
    e.preventDefault();
    console.log("you searched for - " + value);
    const parseGithubUrl = require("parse-github-url");
    const { owner, name } = parseGithubUrl(value);
    console.log({ value, parseGithubUrl: parseGithubUrl(value) });
    history.push({
      pathname: `/search/${owner}/${name}`
    });
  };

  const handleKeypress = (e: any) => {
    if (e.keyCode === 13) {
      handleSubmit(e);
    }
  };

  return (
    <div css={searchInputContainer}>
      <h1>GitHub Issue Viewer</h1>
      <SearchIcon />
      <form>
        <input
          className="searchInput"
          placeholder="Paste a link to a GitHub repo and hit enter!"
          value={value}
          onChange={handleChange}
          onKeyPress={handleKeypress}
        />
        <button onClick={handleSubmit} type="submit">
          Submit
        </button>
      </form>
    </div>
  );
}
