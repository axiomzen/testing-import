import { css } from "@emotion/core";
import theme from "../../shared/theme";

export const searchInputContainer = css`
  position: relative;
  max-width: 800px;
  margin: 0 auto;

  & .searchIcon {
    width: 30px;
    position: absolute;
    left: 25px;
    bottom: 22px;
  }

  & .searchInput {
    padding: 1.4rem 2rem 1.4rem 80px;
    min-width: 60vw;
    width: 100%;
    font-size: 1.6rem;

    & ::placeholder {
      color: ${theme.colors.lightGrey};
    }
  }

  & button {
    display: none;
  }
`;
