import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import useIssues from "../../shared/hooks/useIssues";
import IssueBox from "../IssueBox";
import { issuesPageContainer } from "./IssuesPageStyles";

/**
 *
 *
 * @export
 * @returns {React.ReactElement}
 */
export default function IssuesPage(): React.ReactElement {
  const [activeFilter, setActiveFilterState] = useState("all");
  const [issuesData, setIssuesData] = useState([]);
  const { owner, repo } = useParams<{ owner: string; repo: string; key: string }>();
  const { status, data, error, isFetching }: any = useIssues(
    {
      issuesUrl: `https://api.github.com/repos/${owner}/${repo}/issues?state=${activeFilter}`,
      reactQueryKey: repo + activeFilter
    }
    // Paginated call ref: https://api.github.com/repos/${org}/${repo}/issues?per_page=25&page=${page}
  );

  useEffect(() => {
    document.body.style.background = "white";
  }, []);

  useEffect(() => {
    if (status !== "loading" && status !== "error") {
      setIssuesData(data);
    }
  }, [data, status, setIssuesData]);

  function filterByPr() {
    setActiveFilterState("all");
    const filteredByPr = data.filter((issue: any) => {
      return issue.pull_request;
    });
    setIssuesData(filteredByPr);
  }

  return (
    <div css={issuesPageContainer}>
      <div className="headerContainer row start-xs">
        <div className="col-xs-12">
          <h1 className="headerLeft">GitHub Issue Viewer</h1>
          <p className="headerRight">{`${owner}/${repo}`}</p>
        </div>
        {/* <div className="col-md-4 col-xs-12">
          <p className="headerRight">{`${owner}/${repo}`}</p>
        </div> */}
      </div>

      <div className="col-md-12 buttonsContainer">
        <button
          className={activeFilter === "all" ? "button active" : "button"}
          onClick={() => setActiveFilterState("all")}
        >
          All Issues
        </button>
        <button
          className={activeFilter === "open" ? "button active" : "button"}
          onClick={() => setActiveFilterState("open")}
        >
          Open Issues
        </button>
        <button
          className={activeFilter === "closed" ? "button active" : "button"}
          onClick={() => setActiveFilterState("closed")}
        >
          Closed Issues
        </button>
        <button className="button" onClick={filterByPr}>
          Pull Requests
        </button>
      </div>
      <div className="issuesContainer row">
        {/** TODO: clean this up */}
        {status === "loading" ? (
          <div className="col-md-12 marTop3rem"> Loading...</div>
        ) : status === "error" ? (
          <div className="col-md-12 marTop3rem">Error: {error.message}</div>
        ) : (
          <>
            {issuesData.map((issue: any) => (
              <IssueBox
                key={issue.id}
                title={issue.title}
                body={issue.body}
                isPullRequest={!!issue.pull_request}
                isClosed={issue.state === "closed"}
              />
            ))}

            <div className="col-md-12">{isFetching ? "Background Updating..." : " "}</div>
          </>
        )}
      </div>
    </div>
  );
}
