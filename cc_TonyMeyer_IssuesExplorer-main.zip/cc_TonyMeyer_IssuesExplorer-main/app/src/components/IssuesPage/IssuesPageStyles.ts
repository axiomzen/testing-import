import { css } from "@emotion/core";
import theme from "../../shared/theme";
import { mediaQueryMax } from "../../utils/mediaQuery";

export const issuesPageContainer = css`
  position: relative;
  text-align: left;
  margin-top: 1rem;

  & .buttonsContainer {
    height: 20px;
    margin: 1.5rem 0;
    padding: 2.5rem 0;

    ${mediaQueryMax(theme.breakpoints.md)} {
      padding: 2.5rem 0;
    }
  }

  & .headerContainer {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    padding: 1rem 2rem;
    z-index: 1;
    background: ${theme.colors.hotPink};
    box-shadow: ${theme.shadows.small};
  }

  & .headerLeft {
    margin: 0;
    color: #ffffff;
    font-size: 2.8rem;
    line-height: 2.8rem;
    font-family: ${theme.fonts.montserratBold};

    ${mediaQueryMax(1130)} {
      font-size: 2rem;
      line-height: 2rem;
    }

    ${mediaQueryMax(800)} {
      font-size: 1rem;
      line-height: 1rem;
    }
  }

  & .headerRight {
    text-align: right;

    ${mediaQueryMax(theme.breakpoints.md)} {
      text-align: left;
    }
  }

  & .button {
    background: transparent;
  }

  & .active {
    color: ${theme.colors.hotPink};
  }

  & .marTop3rem {
    margin-top: 3rem;
  }
`;
