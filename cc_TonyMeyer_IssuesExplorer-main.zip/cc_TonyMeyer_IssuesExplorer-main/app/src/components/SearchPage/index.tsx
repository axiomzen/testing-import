import React, { useEffect } from "react";
import SearchInput from "../SearchInput";
export default function SearchPage() {
  useEffect((): any => {
    document.body.style.background = "#E91E63";
  }, []);

  return (
    <div className="col-xs-12">
      <SearchInput />
    </div>
  );
}
