import { css } from "@emotion/core";
import theme from "../../shared/theme";

export const issueBoxContainer = css`
  position: relative;
  text-align: left;
  padding 0.5rem 0.5rem 0.5rem;

  & .iconsContainer {
    position: absolute;
    width: 30px;
    bottom: 30px;
    right: 20px;
    background-color: #e91f62;
    padding: 4px;
    border-radius: 5px;
  }

  & .title {
    margin-bottom: 0;
    padding: 1rem;
    font-size: 18px;
    min-height: 115px;
    color: ${theme.colors.white};
    background-color: ${theme.colors.lightBlue};
  }

  & .body {
    margin-top: 0;
    padding: 1rem;
    font-size: 12px;
    background-color: ${theme.colors.white};
    height: 300px;
    overflow-x: auto;
    box-shadow: ${theme.shadows.small};
  }
`;
