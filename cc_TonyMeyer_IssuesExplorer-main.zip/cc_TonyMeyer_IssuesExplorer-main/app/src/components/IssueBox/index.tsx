import React from "react";
import { issueBoxContainer } from "./issueBoxStyles";
import IssueClosedIcon from "../../shared/IssueClosedIcon";
import PullRequestIcon from "../../shared/PullRequestIcon";

interface Props {
  title: string;
  body: string;
  isPullRequest: boolean;
  isClosed: boolean;
}

/**
 *
 *
 * @export
 * @param {Props} { title, body, isPullRequest, isClosed }
 * @returns {React.ReactElement}
 */
export default function IssueBox({ title, body, isPullRequest, isClosed }: Props): React.ReactElement {
  return (
    <div css={issueBoxContainer} className="col-xs-12 col-md-4">
      {isClosed && (
        <div className="iconsContainer">
          <IssueClosedIcon />
        </div>
      )}
      {isPullRequest && (
        <div className="iconsContainer">
          <PullRequestIcon />
        </div>
      )}
      <h2 className="title">{title}</h2>
      <p className="body">{body}</p>
    </div>
  );
}
