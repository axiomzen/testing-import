import React from "react";
import { BrowserRouter as Router, Route } from "react-router-dom";
import { QueryCache, ReactQueryCacheProvider } from "react-query";
import { ReactQueryDevtools } from "react-query-devtools";
import SearchPage from "./components/SearchPage";
import IssuesPage from "./components/IssuesPage";
import { mainAppContainer } from "./appStyles";

// @ts-ignore
import { AnimatedSwitch } from "react-router-transition";

const queryCache = new QueryCache({
  defaultConfig: {
    queries: {
      refetchOnWindowFocus: false
    }
  }
});

export default function App() {
  return (
    <ReactQueryCacheProvider queryCache={queryCache}>
      <div css={mainAppContainer}>
        <Router>
          <AnimatedSwitch
            atEnter={{ opacity: 0 }}
            atLeave={{ opacity: 0 }}
            atActive={{ opacity: 1 }}
            className="switch-wrapper"
          >
            <Route exact path="/">
              <SearchPage />
            </Route>
            <Route path="/search/:owner/:repo">
              <IssuesPage />
            </Route>
          </AnimatedSwitch>
        </Router>
      </div>
      <ReactQueryDevtools initialIsOpen={false} />
    </ReactQueryCacheProvider>
  );
}
