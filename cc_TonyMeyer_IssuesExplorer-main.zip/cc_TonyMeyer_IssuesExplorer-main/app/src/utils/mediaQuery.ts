export const mediaQueryMin = (width: number) => `@media only screen and (min-width: ${width}px)`;
export const mediaQueryMax = (width: number) => `@media only screen and (max-width: ${width}px)`;
